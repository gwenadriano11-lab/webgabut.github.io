module.exports = {
  tokens: "8428012602:AAHsuXNAvuuQbx-dKDoCHEx1nTaTbPWIBp0",  // Ubah Jadi Token Bot Mu !!!
  owner: "5441177285", // Ubah Jadi Id Mu !!!
  port: "4001", // Ubah Jadi Port Panel Mu !!!
  ipvps: "https://thundercrashteam.pterodactyl-panel.web.id" // Ubah Jadi Ip Vps Mu !!!
};